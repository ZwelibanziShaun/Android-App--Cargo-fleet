package com.example.cargo_fleet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegisterCustomer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer);
    }
}